// TC Rule 함수 모음
var nTCIndex = 1;
var preIndex = 0;
function get테스트케이스순번(row, Dataset, param1, param2) {
	if (preIndex != row) {
		preIndex = row;
		nTCIndex++;
	}
	
	return nTCIndex;
}
